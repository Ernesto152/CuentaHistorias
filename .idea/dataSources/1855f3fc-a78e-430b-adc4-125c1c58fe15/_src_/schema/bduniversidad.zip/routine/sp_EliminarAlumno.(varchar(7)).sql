CREATE PROCEDURE sp_EliminarAlumno(IN cod VARCHAR(7))
  delete from alumno
where codigo=cod;
