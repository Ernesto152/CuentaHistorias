CREATE PROCEDURE sp_GrabarMatricula(IN alu VARCHAR(7), IN cur VARCHAR(10))
  insert into matricula(alu_codigo,cur_codigo) values(alu,cur);
