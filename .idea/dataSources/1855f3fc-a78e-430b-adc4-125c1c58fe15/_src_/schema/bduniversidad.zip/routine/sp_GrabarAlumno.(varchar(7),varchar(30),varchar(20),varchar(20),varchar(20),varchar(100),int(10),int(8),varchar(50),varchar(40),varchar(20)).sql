CREATE PROCEDURE sp_GrabarAlumno(IN cod  VARCHAR(7), IN nom VARCHAR(30), IN ap VARCHAR(20), IN am VARCHAR(20),
                                 IN fnac VARCHAR(20), IN dir VARCHAR(100), IN tel INT(10), IN dni INT(8),
                                 IN car  VARCHAR(50), IN dis VARCHAR(40), IN dep VARCHAR(20))
  insert into alumno(codigo,nombre,apaterno,amaterno,fnacimiento,direccion,telefono,dni,carrera,distrito,departamento)
values(cod,nom,ap,am,fnac,dir,tel,dni,car,dis,dep);
