CREATE TRIGGER calcularPromedio
AFTER INSERT ON nota
FOR EACH ROW
  insert into promedio(alu_codigo,cur_codigo,prom)
values (NEW.alu_codigo,NEW.cur_codigo,(NEW.pc1*0.1+NEW.pc2*0.1+NEW.pc3*0.2+NEW.pc4*0.2+NEW.ef*0.4));
